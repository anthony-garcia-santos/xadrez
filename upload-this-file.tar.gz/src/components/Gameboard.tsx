import { useState, useEffect } from 'react';
import { Game } from '@/libs/game';
import { Position, PlayerColor } from '@/types/game';
import '../style/Board.css';

interface BoardProps {
  game: Game;
  onMove: (from: Position, to: Position) => void;
  selectedPosition: Position | null;
  setSelectedPosition: (pos: Position | null) => void;
  currentPlayer: PlayerColor;
}

export const Board: React.FC<BoardProps> = ({
  game,
  onMove,
  selectedPosition,
  setSelectedPosition,
  currentPlayer,
}) => {
  const [possibleMoves, setPossibleMoves] = useState<Position[]>([]);

  useEffect(() => {
    if (selectedPosition) {
      const moves: Position[] = [];
      const piece = game.board.getPiece(selectedPosition);
      
      if (piece) {
        for (let r = 0; r < game.board.size; r++) {
          for (let c = 0; c < game.board.size; c++) {
            const target = { row: r, col: c };
            if (game.board.isValidMove(selectedPosition, target, currentPlayer)) {
              moves.push(target);
            }
          }
        }
      }
      setPossibleMoves(moves);
    } else {
      setPossibleMoves([]);
    }
  }, [selectedPosition, game, currentPlayer]);

  const handleClick = (row: number, col: number) => {
    const clickedPosition = { row, col };
    const piece = game.board.getPiece(clickedPosition);

    if (selectedPosition) {
      if (game.board.isValidMove(selectedPosition, clickedPosition, currentPlayer)) {
        onMove(selectedPosition, clickedPosition);
      }
      setSelectedPosition(null);
    } else if (piece && piece.color === currentPlayer) {
      setSelectedPosition(clickedPosition);
    }
  };

  const renderPiece = (row: number, col: number) => {
    const piece = game.board.getPiece({ row, col });
    if (!piece) return null;

    const pieceImages = {
      developer: `/images/developer_${piece.color}.png`,
      designer: `/images/designer_${piece.color}.png`,
      product_owner: `/images/product_owner_${piece.color}.png`,
    };

    return (
      <img 
        src={pieceImages[piece.type]} 
        alt={`${piece.color} ${piece.type}`}
        className="piece-image"
      />
    );
  };

  return (
    <div className="board">
      {game.board.grid.map((row, rowIndex) =>
        row.map((_, colIndex) => {
          const isLight = (rowIndex + colIndex) % 2 === 0;
          const isSelected = selectedPosition?.row === rowIndex && 
                            selectedPosition?.col === colIndex;
          const isPossibleMove = possibleMoves.some(
            move => move.row === rowIndex && move.col === colIndex
          );

          return (
            <div
              key={`${rowIndex}-${colIndex}`}
              onClick={() => handleClick(rowIndex, colIndex)}
              className={`cell ${isLight ? 'cell-light' : 'cell-dark'} ${
                isSelected ? 'cell-selected' : ''
              }`}
            >
              {renderPiece(rowIndex, colIndex)}
              {isPossibleMove && !game.board.getPiece({ row: rowIndex, col: colIndex }) && (
                <div className="move-indicator" />
              )}
            </div>
          );
        })
      )}
    </div>
  );
};